from .gambling_simulator import *

__doc__ = gambling_simulator.__doc__
if hasattr(gambling_simulator, "__all__"):
    __all__ = gambling_simulator.__all__